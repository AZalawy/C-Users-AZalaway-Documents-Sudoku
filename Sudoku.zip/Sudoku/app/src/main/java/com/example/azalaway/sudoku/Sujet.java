package com.example.azalaway.sudokumaster;

import android.os.Bundle;
import android.app.Activity;

public class Sujet extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);
    }
}
